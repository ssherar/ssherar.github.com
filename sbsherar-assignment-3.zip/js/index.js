// Look ma! no jQuery

(function(win, doc) {
  win.onload = function() {
    /** Kick off validation*/
    Validator_init();

    var API = new AJAX("https://api.github.com");
    var template = new Template("#list");

    /** 
     * Helper function for creating the search query string which Github requests.
     *
     * See https://developer.github.com/v3/search/#search-repositories for more context
     */
    createQueryString = function(obj) {
      q = '';
      if (obj["keyword"] !== undefined) {
        q += `${obj["keyword"]}+`;
        obj["keyword"] = undefined;
      } else { 
        throw Error("Keyword must be set");
      }

      for (key in obj) {
        switch(key) {
          case "language":
            if (obj[key] === '') break;
            q += `language:${obj[key].toLowerCase()}`;
            break;
          default:
            break;
        }
        q += "+"
      }

      return q.slice(0, -1);
    }

    /** Where the magic happens */
    doc.querySelector("#search").addEventListener("submit", function(e) {
      e.preventDefault();

      $results = doc.querySelector("#results");
      $results.innerHTML = "<li>Data loading... Please wait</li>";

      params = {};
      params["q"] = createQueryString({
        keyword: doc.querySelector("#searchPhrase").value,
        language: doc.querySelector("#langChoice").value
      });

      if (doc.querySelector("#useStars").checked) {
        params["sort"] = "stars";
      }
      
      API.getJSON("/search/repositories", params,  data => {
        $results.innerHTML = "";

        if(data.total_count == 0 ) {
          alert("There was no items found. Please try again");
        } else {
          data.items.forEach((item) => {
            t = template.render(item);
            $results.insertAdjacentHTML("beforeend", t);
          }) 
        }
      })
    }, false);
  }

})(window, document);
/** Made with 100% original ES6. Nothing more; never less */
