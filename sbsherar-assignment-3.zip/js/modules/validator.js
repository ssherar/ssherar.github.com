// Look ma! No jQuery!
//
// Some might say this is over-engineered for what the assignment is for. But
// seeing as I've been doing web development for 10+ years, I thought let's 
// snaz it up a little.
//
// The premise of this, is that the user should /NEVER/ need to touch javascript to
// have form validation on their site. The idea of this is an old one which I first
// implemented in 2007, back in the day where xHTML4.1 was around, and ES6 was just
// a dream. Back then, attributes were a lot harder to manipulate, and IE8 will through
// a fit if you ever manipulated them. Therefore it was implemented using `data-` attributes.
//
// With the move of `Shadow doms` and `Web Components`, the DOM is a lot more
// relaxed in comparison to the older stiff necked standards. Look at Polymer and React for the
// gist. (However, I /hope/ this is not a new revelation to yourselves...)
//
// The library handles everything throygh these attributes, and doing a search
// against predefined callbacks, which do the validation depending on the value
// of the attribute, and returns either an error or null. if it errors out, it
// will stop the submission of the form (which has the validate attribute) and alert
// the user.
//
// i.e. if you want to validate that a string is of a certain type, the user is able
// to use the regexr attribute with a valid regex expression. (regular expression expression?)
// such as <input type="input" name="name" regexr="^\w+$"> to validate a first name.
//
// On the hiding element of it, again, it has been decoupled with hardcoded Javascript.
// Instead it checks for two different attributes are existing together: hidden and depends-on.
// Hidden is self explanitory, but the cool logic comes from depends-on. It should
// be formed of "Select Field id"#"Option Value". **NB**: For simplicity sake, the select field
// Must have the attribute "conditional-field", but it ultimately doesn't have to if
// some time was spent on the logic.
//
// Once the selection is made, it will remove the hidden attributes and change the CSS
// back to display as correctly. If it's unselected, it will add the attribute back in again,
// and hide the field in CSS.
//
// Neato.
//
// So I can see some arguments forming. The main argument I will have with myself is:
//
//    "Hey Sam, cool idea, but surely using attributes which are not unique to
//    your library could cause confusion and maybe regression errors as and 
//    when the W3C updates the HTML5 spec?"
//
// That is true, and very good point. However, this is a POC for an assignment, which
// has taken me 73 minutes to write. It is definitely not prod ready, and maybe a
// whiteboard will be needed for any serious thought of structured development.
// 
// Another argument is:
// 
//    "Hey Sam, this is way over engineered for an IU assignment - all I wanted was
//    a case/switch as dictated on the depreciated `onchange` html attribute!"
//
// Again, if we are going to do something that I taught my 7 year old niece to do,
// I want to get some add-value from it. ES6 is relatively new to me, and using it
// for a mundane task such as this is a perfect excuse to learn something from this
// course.
//
// If you want to have a discussion over this code, ping me on the slack group: @sam.
//
// Cheerio,
//
// Sam

(function(win, dom) {
  /**
   * An object which stores the validation callbacks. It is important that the name
   * is exactly the same as the attribute you store.
   *
   * A callback takes 2 arguments:
   *   - the element you are currently manipulating (input, textarea, etc)
   *   - the attribute map from said element as convienance
   *
   * Returning a non-null value will cause the validation script to cancel submission
   * and alert the user with the value returned as part of the error message. Therefore
   * it is vital to describe to the user what went wrong instead of returning an error
   * code.
   */
  let validation_ruleset = {
    regexr(element, attribute) {
      let re = new RegExp(attribute.value);
      if (re.test(element.value) === true) {
        return null;
      } else {
        label = element.labels[0];
        human_name = (label !== undefined) ? label.innerText.substring(0, label.innerText.length - 1) : element.name;
        return `${human_name} is not in a correct format. Please try again.`;
      }
    },

    /**
     * Chrome and new browsers should already handle this. Bit of polyfill if not
     */
    required(element) {
      if (element.value.length > 0) {
        return null;
      } else {
        label = element.labels[0];
        human_name = (label !== undefined) ? label.innerText.substring(0, label.innerText.length - 1) : element.name;
        return `${human_name} is required`;
      }
    }
  }

  /**
   * Tick, tock.
   *
   * The work horse for input submission. Logic is as follows:
   *
   *   - Only select elements in the form which are inputs
   *   - If that element is hidden, then ignore.
   *   - Pull attributes and check if there is an associated callback
   *   - If so, run the callback and store the error message if there is one
   *   - If errors is an non-empty array, stop submission and alert the user.
   *
   * @param e the event which is passed in from the event handler
   */
  let handle_validation = function(e) {
    let errors = [];
    fields = e.target.querySelectorAll("input, select, textarea, checkbox");
    for (field of fields) {
      let attribs = field.attributes;
      if (attribs["hidden"] !== undefined) {
        continue;
      }

      for (attrib of attribs) {
        cb = validation_ruleset[attrib.name];
        if (cb !== undefined) {
          error = cb(field, attrib);
          if(error) errors.push(error);
        }
      }
    }

    if (errors.length > 0) {
      message = errors.join("\n");
      alert(message);
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }

  /**
   * The work horse for hiding fields which we don't want to see
   * depending on a selection.
   *
   * Logic is as follows:
   *
   *    - For each options, verify which values are selected
   *    - For each selected values, find the field assocated to it an
   *      unhide the value
   *    - For other fields which are not part of the selected array,
   *      hide this value
   * 
   * @param e event passed in from the event handler
   */
  let handle_hiddens = function(e) {
    var selected_values = [];

    field = hidden_conditionals[e.target.name];

    for(var i = 0; i < e.target.options.length; i++) {
      opt = e.target.options[i];
      if (opt.selected) {
        selected_values.push(opt.value);
      }
    }

    selected_values.forEach((e) => {
      element = field[e];
      if (element === undefined) {
        alert(`Sorry! there is no ${e} field`);
        return;
      }

      element.hidden = undefined;
      element.labels[0].style.display = "inline-block";
    });

    for (var prop in field) {
      if (selected_values.indexOf(prop) == -1) {
        field[prop].hidden = true;
        field[prop].labels[0].style.display = "none";
      }
    }
  }

  /**
   * Bootstrap the hidden fields before the onload event is triggered.
   */
  let hidden_conditionals = {};
  (function() {
    var hidden_fields = dom.querySelectorAll('input[hidden]:not([depends-on=""])');

    hidden_fields.forEach((e) => {
      depends_on = e.attributes["depends-on"];
      [field, value, ..._] = depends_on.value.split("#");
      arr = hidden_conditionals[field] || {};
      arr[value] = e;
      hidden_conditionals[field] = arr;
      e.labels[0].style.display = 'none';
    });
  })();

  /**
   * Let's get this party started?!
   */
  win.Validator_init = function() {
    var forms = dom.querySelectorAll("form[validate]");
    forms.forEach((form) => {
      form.querySelectorAll("select[conditional-field]").forEach((select) => {
        select.addEventListener("change", handle_hiddens, false);
      })
      form.addEventListener("submit", handle_validation, false);
    });
  }
})(window, document);
/** Made with 100% original ES6. Nothing more; never less */
