(function(win) {

  function Template(selector) {
    this.selector = selector;
    this.html = document.querySelector(selector).innerHTML;
    this.variableCache = [];
    this.getTemplateVariables();
  }

  Template.prototype.getTemplateVariables = function() {
    var varRegex = /\{\{(\w+)\}\}/gim;
    while(match = varRegex.exec(this.html)) {
      this.variableCache.push(match[1]);
    }
  }

  Template.prototype.render = function(data) {
    var t;

    this.variableCache.forEach((key) => {
      var exp = new RegExp(`\{\{${key}\}\}`);
      t = (t || this.html).replace(exp, data[key]);
    });

    return t;
  }

  win.Template = Template;
})(window);
/** Made with 100% original ES6. Nothing more; never less */
