// Look ma! no jQuery

(function(win) {
  function AJAX(endpoint) {
    this.endpoint = endpoint;
  }

  AJAX.prototype.get = function(slug, params, cb) {
    if (typeof(params) == "function") cb = params;
    if (typeof(params) == "object") slug = this.buildQuery(slug, params);
    
    let xhr = new XMLHttpRequest();
    xhr.onload = function() {
      cb(this.responseText);
    };
    xhr.open("GET", this.endpoint+slug, true);
    xhr.send();
  }

  AJAX.prototype.getJSON = function(slug, params, cb) {
    this.get(slug, params, (data) => cb(JSON.parse(data)));
  }

  AJAX.prototype.buildQuery = function(slug, params) {
    qArr = [];
    for (k in params) {
      qArr.push(`${k}=${params[k]}`);
    }
    return `${slug}?${qArr.join("&")}`;
  }

  win.AJAX = AJAX;
})(window)
/** Made with 100% original ES6. Nothing more; never less */
